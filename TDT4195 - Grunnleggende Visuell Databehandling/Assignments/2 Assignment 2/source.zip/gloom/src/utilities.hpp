#pragma once

unsigned int rangedInput(float &var, float &increment, 
    float lowerBound, float upperBound);

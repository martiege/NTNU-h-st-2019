// Local headers
#include "program.hpp"
#include "gloom/gloom.hpp"
#include "triangle.hpp"
#include "gloom/shader.hpp"

// Standard headers
#include <vector>


void runProgram(GLFWwindow* window)
{
    Gloom::Shader shader;
    shader.attach("../gloom/shaders/simple.frag");
    shader.attach("../gloom/shaders/simple.vert");
    shader.link();

    // Enable depth (Z) buffer (accept "closest" fragment)
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    // Configure miscellaneous OpenGL settings
    glEnable(GL_CULL_FACE);

    // Set default colour after clearing the colour buffer
    glClearColor(0.3f, 0.5f, 0.8f, 1.0f);

    // Set up your scene here (create Vertex Array Objects, etc.)
    std::vector<float> triangleVertices = {
        -0.9,  0.1, 0.0,
        -0.1,  0.1, 0.0,
        -0.9,  0.9, 0.0
    };
    std::vector<int> triangleIndices = {
        0, 1, 2
    };

    unsigned int triangleVaoID = createTriangleVertexArrayObject(
        triangleVertices,
        triangleIndices
    );

    // Rendering Loop
    while (!glfwWindowShouldClose(window))
    {
        // Clear colour and depth buffers
        glClear(
            GL_COLOR_BUFFER_BIT 
            | GL_DEPTH_BUFFER_BIT
        );
        
        shader.activate();

        // Draw your scene here
        drawTriangleVertexArrayObject(triangleVaoID, triangleIndices.size());

        shader.deactivate();

        // Handle other events
        glfwPollEvents();
        handleKeyboardInput(window);

        // Flip buffers
        glfwSwapBuffers(window);
    }

    shader.destroy();
}


void handleKeyboardInput(GLFWwindow* window)
{
    // Use escape key for terminating the GLFW window
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, GL_TRUE);
    }
}

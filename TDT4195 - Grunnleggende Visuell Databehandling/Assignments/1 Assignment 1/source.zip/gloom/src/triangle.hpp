#pragma once

#include <vector>


unsigned int createTriangleVertexArrayObject(
    std::vector<float> vertices, 
    std::vector<int> indices
);

void drawTriangleVertexArrayObject(unsigned int vaoID, unsigned int indexCount);

